# Como publicar o SportLife na internet (gratuito)

Este guia mostra dois caminhos gratuitos para colocar o site no ar, sem precisar de
cartão de crédito. Recomendo o **PythonAnywhere** porque ele mantém o banco SQLite
salvo de forma permanente — ótimo para o TCC, já que os dados não somem entre uma
demonstração e outra.

---

## Opção 1 — PythonAnywhere (recomendado)

### 1. Crie a conta
Acesse [pythonanywhere.com](https://www.pythonanywhere.com), crie uma conta gratuita
("Beginner") e faça login.

### 2. Suba o código
No dashboard, abra um **Bash console** (menu "Consoles" → "Bash") e clone ou envie
seu projeto. Se você for subir o `.zip`:
- Vá em "Files", crie uma pasta `sportlife` e faça upload do zip.
- No Bash console, descompacte: `unzip SportLife_corrigido.zip -d sportlife`

### 3. Crie o ambiente virtual e instale as dependências
No Bash console:
```bash
cd ~/sportlife/SportLife
mkvirtualenv --python=/usr/bin/python3.10 sportlife-venv
pip install -r requirements.txt
```

### 4. Configure as variáveis de ambiente
Edite o arquivo `.env` (pelo editor de arquivos do PythonAnywhere) e troque o valor de
`SECRET_KEY` por um valor novo e aleatório (não use o mesmo do seu ambiente local).
Defina `FLASK_DEBUG=0`, já que isso é produção.

### 5. Crie o Web App
- Vá em "Web" → "Add a new web app" → "Next" → escolha **Manual configuration**
  (não escolha o template "Flask" automático, porque ele cria um app novo do zero) →
  selecione a mesma versão de Python do passo 3.
- Em **Virtualenv**, informe o caminho: `/home/SEUUSUARIO/.virtualenvs/sportlife-venv`
- Em **Code**, defina o "Source code" como `/home/SEUUSUARIO/sportlife/SportLife`.
- Abra o link do **WSGI configuration file** e substitua o conteúdo por:

```python
import sys
import os

path = '/home/SEUUSUARIO/sportlife/SportLife'
if path not in sys.path:
    sys.path.insert(0, path)

os.chdir(path)

from app import app as application
```

(troque `SEUUSUARIO` pelo seu usuário do PythonAnywhere nas duas linhas)

### 6. Configure os arquivos estáticos
Ainda na aba "Web", em **Static files**, adicione:
- URL: `/static/` → Directory: `/home/SEUUSUARIO/sportlife/SportLife/static`

### 7. Recarregue
Clique no botão verde **Reload** no topo da aba "Web". Seu site estará em:
`https://SEUUSUARIO.pythonanywhere.com`

> Sempre que você alterar o código, repita: salvar o arquivo → clicar em **Reload**.

---

## Opção 2 — Render (alternativa)

Mais rápido se o projeto já estiver num repositório do GitHub, mas atenção:
no plano gratuito do Render, o disco é **temporário** — o arquivo do banco SQLite
(`instance/sportlife.db`) pode ser apagado a cada novo deploy ou reinício do serviço.
Para uma demonstração ao vivo funciona bem; não confie nele para guardar dados por
muito tempo.

### Passos
1. Suba o projeto para um repositório no GitHub (sem o arquivo `.env`, ele já está
   no `.gitignore`).
2. Em [render.com](https://render.com), crie uma conta gratuita e clique em
   **New** → **Web Service**.
3. Conecte o repositório do GitHub.
4. Configure:
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app` (já está pronto no arquivo `Procfile`)
5. Em **Environment Variables**, adicione:
   - `SECRET_KEY` → gere um valor novo e aleatório
   - `FLASK_DEBUG` → `0`
6. Clique em **Create Web Service**. O Render já injeta a variável `PORT`
   automaticamente, e o `app.py` já está preparado para ler ela.

---

## Opção 3 — Hostinger (VPS)

Importante entender antes de contratar: hospedagem **compartilhada** da Hostinger
(a mais barata, focada em WordPress/PHP) **não roda Flask**. Para publicar este
projeto na Hostinger você precisa de um plano **VPS** (ex: KVM 1), que dá acesso
root via SSH a um servidor Ubuntu — aí sim dá para instalar Python normalmente.

### 1. Contrate o VPS e acesse via SSH
No hPanel da Hostinger, crie o VPS com Ubuntu. Depois conecte:
```bash
ssh root@SEU_IP_DO_VPS
```

### 2. Instale as dependências do sistema
```bash
apt update && apt install -y python3-venv python3-pip nginx git
```

### 3. Envie o projeto para o servidor
Envie o `.zip` por SCP (do seu computador) ou clone de um repositório Git:
```bash
scp SportLife_v5.zip root@SEU_IP_DO_VPS:/root/
ssh root@SEU_IP_DO_VPS "unzip SportLife_v5.zip -d /var/www/sportlife"
```

### 4. Crie o ambiente virtual e instale as dependências
```bash
cd /var/www/sportlife/SportLife
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 5. Configure o `.env` de produção
Edite `.env` (`nano .env`), gere uma `SECRET_KEY` nova (veja a seção abaixo) e
defina `FLASK_DEBUG=0`.

### 6. Rode com Gunicorn como serviço (systemd)
Crie `/etc/systemd/system/sportlife.service`:
```ini
[Unit]
Description=SportLife (Gunicorn)
After=network.target

[Service]
WorkingDirectory=/var/www/sportlife/SportLife
ExecStart=/var/www/sportlife/SportLife/venv/bin/gunicorn -w 3 -b 127.0.0.1:8000 app:app
Restart=always

[Install]
WantedBy=multi-user.target
```
Depois:
```bash
systemctl daemon-reload
systemctl enable --now sportlife
```

### 7. Aponte o Nginx para o Gunicorn
Crie `/etc/nginx/sites-available/sportlife`:
```nginx
server {
    listen 80;
    server_name SEUDOMINIO.com;

    location /static/ {
        alias /var/www/sportlife/SportLife/static/;
    }

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```
```bash
ln -s /etc/nginx/sites-available/sportlife /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

### 8. Aponte seu domínio e ative HTTPS
No hPanel, aponte o DNS do domínio (registro A) para o IP do VPS. Depois de o DNS
propagar, ative HTTPS grátis com Certbot:
```bash
apt install -y certbot python3-certbot-nginx
certbot --nginx -d SEUDOMINIO.com
```

Pronto — o site fica em `https://SEUDOMINIO.com`. Sempre que alterar o código,
suba os arquivos novos e rode `systemctl restart sportlife`.

---



Nunca reaproveite a chave do seu `.env` local em produção. Para gerar uma nova,
rode no terminal (com Python instalado):

```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

Copie o valor gerado e cole na variável `SECRET_KEY` da hospedagem escolhida.
